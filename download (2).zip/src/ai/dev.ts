import { config } from 'dotenv';
config();

import '@/ai/flows/ai-shopping-assistant.ts';
import '@/ai/flows/product-description-generator.ts';